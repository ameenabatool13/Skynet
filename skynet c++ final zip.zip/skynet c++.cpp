#include <iostream>
#include <string>
using namespace std;

// ============================================================
// CONSTANTS
// ============================================================
const int MAX = 10;
const int INF = 9999;

// ============================================================
// ABSTRACTION - Abstract Base Class
// ============================================================
class GraphNode {
protected:
    string code;
    string name;

public:
    GraphNode() {}
    GraphNode(string c, string n) : code(c), name(n) {}

    virtual void display() const = 0;  // Pure virtual = Abstraction

    string getCode() const { return code; }
    string getName() const { return name; }

    virtual ~GraphNode() {}
};

// ============================================================
// INHERITANCE + POLYMORPHISM - Airport extends GraphNode
// ============================================================
class Airport : public GraphNode {
private:
    string city;
    string country;

public:
    Airport() {}
    Airport(string code, string name, string city, string country)
        : GraphNode(code, name), city(city), country(country) {}

    // Polymorphism - overrides base class display()
    void display() const override {
        cout << "[" << code << "] " << name << " | " << city << ", " << country << "\n";
    }

    string getCity()    const { return city; }
    string getCountry() const { return country; }
};

// ============================================================
// ENCAPSULATION - Route (directed edge with weight)
// ============================================================
class Route {
private:
    string from;
    string to;
    int    hours;

public:
    Route() : hours(0) {}
    Route(string f, string t, int h) : from(f), to(t), hours(h) {}

    string getFrom()  const { return from; }
    string getTo()    const { return to; }
    int    getHours() const { return hours; }
};

// ============================================================
// SKYNET - Main Graph Engine
// ============================================================
class SkyNet {
private:
    // --- Data ---
    Airport airports[MAX];
    int     airportCount;

    Route   routes[MAX * MAX];
    int     routeCount;

    // Adjacency matrix  [i][j] = flight hours, 0 = no direct flight
    int     adj[MAX][MAX];

    // Transitive closure [i][j] = 1 if reachable
    int     reach[MAX][MAX];

    // --- Helpers ---

    // Return index of airport by code, -1 if not found
    int indexOf(const string& code) const {
        for (int i = 0; i < airportCount; i++)
            if (airports[i].getCode() == code)
                return i;
        return -1;
    }

    // Warshall's Algorithm - builds transitive closure
    void buildTransitiveClosure() {
        // Copy direct connections
        for (int i = 0; i < airportCount; i++)
            for (int j = 0; j < airportCount; j++)
                reach[i][j] = (adj[i][j] > 0) ? 1 : 0;

        // Every airport can reach itself
        for (int i = 0; i < airportCount; i++)
            reach[i][i] = 1;

        // Warshall's: if i->k and k->j then i->j
        for (int k = 0; k < airportCount; k++)
            for (int i = 0; i < airportCount; i++)
                for (int j = 0; j < airportCount; j++)
                    if (reach[i][k] && reach[k][j])
                        reach[i][j] = 1;
    }

    // DFS to find all paths from src to dest
    // path[]  = current path (array of indices)
    // pathLen = how many airports in current path
    // visited = which airports visited so far
    // allPaths[pathCount][] = saved complete paths
    // allDurations[] = total hours for each saved path

    void dfs(int src, int dest,
             int path[], int pathLen,
             bool visited[],
             int allPaths[][MAX], int allDurations[], int& pathCount)
    {
        if (src == dest) {
            // Save this path
            for (int i = 0; i < pathLen; i++)
                allPaths[pathCount][i] = path[i];
            allPaths[pathCount][pathLen] = -1; // sentinel
            // Calculate total duration for this path
            int total = 0;
            for (int i = 0; i + 1 < pathLen; i++)
                total += adj[ path[i] ][ path[i+1] ];
            allDurations[pathCount] = total;
            pathCount++;
            return;
        }

        visited[src] = true;

        for (int next = 0; next < airportCount; next++) {
            if (adj[src][next] > 0 && !visited[next]) {
                path[pathLen] = next;
                dfs(next, dest, path, pathLen + 1, visited,
                    allPaths, allDurations, pathCount);
            }
        }

        visited[src] = false;
    }

public:

    SkyNet() : airportCount(0), routeCount(0) {
        for (int i = 0; i < MAX; i++)
            for (int j = 0; j < MAX; j++) {
                adj[i][j]   = 0;
                reach[i][j] = 0;
            }
    }

    // --------------------------------------------------------
    // Add airport to network
    // --------------------------------------------------------
    void addAirport(string code, string name, string city, string country) {
        airports[airportCount++] = Airport(code, name, city, country);
    }

    // --------------------------------------------------------
    // Add directed route (from -> to, flight hours)
    // --------------------------------------------------------
    void addRoute(string from, string to, int hours) {
        int f = indexOf(from);
        int t = indexOf(to);
        if (f == -1 || t == -1) {
            cout << "Error: airport not found!\n";
            return;
        }
        routes[routeCount++] = Route(from, to, hours);
        adj[f][t] = hours;
    }

    // --------------------------------------------------------
    // Build the network (compute transitive closure)
    // --------------------------------------------------------
    void build() {
        buildTransitiveClosure();
        cout << "\n[SkyNet] Network built. Transitive closure computed.\n";
    }

    // --------------------------------------------------------
    // Show all airports
    // --------------------------------------------------------
    void showAirports() const {
        cout << "\n===== AIRPORTS =====\n";
        for (int i = 0; i < airportCount; i++)
            airports[i].display();
    }

    // --------------------------------------------------------
    // Show adjacency matrix
    // --------------------------------------------------------
    void showAdjMatrix() const {
        cout << "\n===== ADJACENCY MATRIX (hours) =====\n";
        cout << "     ";
        for (int j = 0; j < airportCount; j++)
            cout << airports[j].getCode() << "   ";
        cout << "\n";

        for (int i = 0; i < airportCount; i++) {
            cout << airports[i].getCode() << "   ";
            for (int j = 0; j < airportCount; j++) {
                if (adj[i][j] == 0)
                    cout << " -   ";
                else
                    cout << " " << adj[i][j] << "   ";
            }
            cout << "\n";
        }
    }

    // --------------------------------------------------------
    // Show transitive closure matrix
    // --------------------------------------------------------
    void showReachability() const {
        cout << "\n===== TRANSITIVE CLOSURE (Warshall) =====\n";
        cout << "     ";
        for (int j = 0; j < airportCount; j++)
            cout << airports[j].getCode() << " ";
        cout << "\n";

        for (int i = 0; i < airportCount; i++) {
            cout << airports[i].getCode() << "   ";
            for (int j = 0; j < airportCount; j++)
                cout << " " << reach[i][j] << " ";
            cout << "\n";
        }
    }

    // --------------------------------------------------------
    // Find & display all paths, then recommend the optimal one
    // --------------------------------------------------------
    void findOptimalPath(const string& srcCode, const string& destCode) {
        cout << "\n===== ROUTE SEARCH: " << srcCode << " --> " << destCode << " =====\n";

        int s = indexOf(srcCode);
        int d = indexOf(destCode);

        if (s == -1 || d == -1) {
            cout << "Error: invalid airport code.\n";
            return;
        }

        if (!reach[s][d]) {
            cout << "No path exists between " << srcCode << " and " << destCode << ".\n";
            return;
        }

        cout << "[OK] Path exists (confirmed via transitive closure)\n";

        // Run DFS to collect all paths
        int  allPaths[50][MAX];
        int  allDurations[50];
        int  pathCount = 0;
        bool visited[MAX] = {};
        int  path[MAX];

        path[0] = s;
        dfs(s, d, path, 1, visited, allPaths, allDurations, pathCount);

        if (pathCount == 0) {
            cout << "No itinerary found.\n";
            return;
        }

        // Simple bubble sort by duration (ascending)
        for (int i = 0; i < pathCount - 1; i++)
            for (int j = 0; j < pathCount - i - 1; j++)
                if (allDurations[j] > allDurations[j + 1]) {
                    // swap durations
                    int tmp = allDurations[j];
                    allDurations[j] = allDurations[j + 1];
                    allDurations[j + 1] = tmp;
                    // swap paths
                    for (int k = 0; k < MAX; k++) {
                        int tp = allPaths[j][k];
                        allPaths[j][k] = allPaths[j+1][k];
                        allPaths[j+1][k] = tp;
                    }
                }

        // Display all paths
        cout << "\n----- ALL ITINERARIES (shortest first) -----\n";
        for (int i = 0; i < pathCount; i++) {
            cout << "Path " << (char)('A' + i) << ": ";
            for (int k = 0; allPaths[i][k] != -1; k++) {
                cout << airports[ allPaths[i][k] ].getCode();
                if (allPaths[i][k + 1] != -1) cout << " --> ";
            }
            cout << " | Total: " << allDurations[i] << " hours\n";
        }

        // Optimal = first after sorting
        cout << "\n[OPTIMAL] Recommended: ";
        for (int k = 0; allPaths[0][k] != -1; k++) {
            cout << airports[ allPaths[0][k] ].getCode();
            if (allPaths[0][k + 1] != -1) cout << " --> ";
        }
        cout << " | " << allDurations[0] << " hours\n";
    }
};

// ============================================================
// MAIN
// ============================================================
int main() {
    cout << "===========================================\n";
    cout << "   SKYNET INTELLIGENT ROUTING SYSTEM\n";
    cout << "   Name: Ameena Batool | SP25-BSCS-0014\n";
    cout << "===========================================\n";

    SkyNet skynet;

    skynet.addAirport("KHI", "Jinnah Int'l Airport",   "Karachi",  "Pakistan");
    skynet.addAirport("DXB", "Dubai Int'l Airport",    "Dubai",    "UAE");
    skynet.addAirport("LHR", "Heathrow Airport",       "London",   "UK");
    skynet.addAirport("IST", "Istanbul Airport",       "Istanbul", "Turkey");
    skynet.addAirport("JFK", "John F Kennedy Airport", "New York", "USA");
    skynet.addAirport("DOH", "Hamad Int'l Airport",    "Doha",     "Qatar");

    skynet.addRoute("KHI", "DXB", 3);
    skynet.addRoute("KHI", "LHR", 9);
    skynet.addRoute("KHI", "IST", 7);
    skynet.addRoute("KHI", "DOH", 3);
    skynet.addRoute("DXB", "JFK", 14);
    skynet.addRoute("LHR", "JFK", 6);
    skynet.addRoute("IST", "JFK", 10);
    skynet.addRoute("DOH", "LHR", 7);
    skynet.addRoute("DOH", "JFK", 13);

    skynet.build();
    skynet.showAirports();
    skynet.showAdjMatrix();
    skynet.showReachability();
    skynet.findOptimalPath("KHI", "JFK");

    return 0;
}