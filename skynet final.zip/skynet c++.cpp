#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>

using namespace std;

// ============================================================
// BASE CLASS - Abstract Graph Node (Abstraction + Inheritance)
// ============================================================
class Node {
protected:
    string code;
    string name;
    string city;

public:
    Node() {}
    Node(string code, string name, string city)
        : code(code), name(name), city(city) {}

    virtual void display() const = 0;

    string getCode() const { return code; }
    string getName() const { return name; }
    string getCity() const { return city; }

    virtual ~Node() {}
};

// ============================================================
// DERIVED CLASS - Airport (Inheritance)
// ============================================================
class Airport : public Node {
private:
    string country;

public:
    Airport() {}
    Airport(string code, string name, string city, string country)
        : Node(code, name, city), country(country) {}

    void display() const override {
        cout << "[" << code << "] " << name << " - " << city << ", " << country;
    }

    string getCountry() const { return country; }
};

// ============================================================
// ROUTE CLASS - Directed Edge with weight (Encapsulation)
// ============================================================
class Route {
private:
    string from;
    string to;
    int duration;
    string airline;

public:
    Route(string from, string to, int duration, string airline)
        : from(from), to(to), duration(duration), airline(airline) {}

    string getFrom()    const { return from; }
    string getTo()      const { return to; }
    int getDuration()   const { return duration; }
    string getAirline() const { return airline; }
};

// ============================================================
// FLIGHT PATH - Represents one full itinerary
// ============================================================
class FlightPath {
private:
    vector<string> stops;
    int totalDuration;

public:
    FlightPath() : totalDuration(0) {}

    void addStop(const string& airport) { stops.push_back(airport); }
    void addDuration(int d) { totalDuration += d; }

    int getTotalDuration() const { return totalDuration; }
    vector<string> getStops() const { return stops; }

    void display() const {
        for (int i = 0; i < (int)stops.size(); i++) {
            cout << stops[i];
            if (i < (int)stops.size() - 1) cout << " --> ";
        }
        cout << " | Total: " << totalDuration << " hours";
    }
};

// ============================================================
// SKYNET - Main Routing Engine
// ============================================================
class SkyNet {
private:
    map<string, Airport>          airports;
    vector<Route>                 routes;
    map<string, map<string, int>> adjMatrix;
    map<string, map<string, bool>> reachability;

    void computeTransitiveClosure() {
        vector<string> codes;
        for (auto& p : airports) codes.push_back(p.first);

        for (auto& a : codes)
            for (auto& b : codes)
                reachability[a][b] = false;

        for (auto& r : routes)
            reachability[r.getFrom()][r.getTo()] = true;

        for (auto& a : codes)
            reachability[a][a] = true;

        for (auto& k : codes)
            for (auto& i : codes)
                for (auto& j : codes)
                    if (reachability[i][k] && reachability[k][j])
                        reachability[i][j] = true;
    }

    void dfs(const string& current,
             const string& dest,
             map<string, bool>& visited,
             FlightPath& current_path,
             vector<FlightPath>& all_paths)
    {
        if (current == dest) {
            all_paths.push_back(current_path);
            return;
        }

        visited[current] = true;

        for (auto& route : routes) {
            if (route.getFrom() == current && !visited[route.getTo()]) {
                FlightPath next_path = current_path;
                next_path.addStop(route.getTo());
                next_path.addDuration(route.getDuration());
                dfs(route.getTo(), dest, visited, next_path, all_paths);
            }
        }

        visited[current] = false;
    }

public:

    void addAirport(const string& code, const string& name,
                    const string& city, const string& country) {
        airports[code] = Airport(code, name, city, country);
    }

    void addRoute(const string& from, const string& to,
                  int duration, const string& airline) {
        routes.push_back(Route(from, to, duration, airline));
        adjMatrix[from][to] = duration;
    }

    void build() {
        computeTransitiveClosure();
        cout << "\n[SkyNet] Network built. Transitive closure computed.\n";
    }

    void showAirports() const {
        cout << "\n===== AIRPORTS IN NETWORK =====\n";
        for (auto& p : airports) {
            p.second.display();
            cout << "\n";
        }
    }

    void showAdjacencyMatrix() const {
        cout << "\n===== ADJACENCY MATRIX (flight duration in hours) =====\n";

        vector<string> codes;
        for (auto& p : airports) codes.push_back(p.first);
        sort(codes.begin(), codes.end());

        cout << "     ";
        for (auto& c : codes) cout << c << "  ";
        cout << "\n";

        for (auto& from : codes) {
            cout << from << "  ";
            for (auto& to : codes) {
                auto it1 = adjMatrix.find(from);
                if (it1 != adjMatrix.end()) {
                    auto it2 = it1->second.find(to);
                    if (it2 != it1->second.end())
                        cout << " " << it2->second << "  ";
                    else
                        cout << " -   ";
                } else {
                    cout << " -   ";
                }
            }
            cout << "\n";
        }
    }

    void showReachability() const {
        cout << "\n===== TRANSITIVE CLOSURE (Warshall's Algorithm) =====\n";

        vector<string> codes;
        for (auto& p : airports) codes.push_back(p.first);
        sort(codes.begin(), codes.end());

        cout << "     ";
        for (auto& c : codes) cout << c << " ";
        cout << "\n";

        for (auto& from : codes) {
            cout << from << "  ";
            for (auto& to : codes) {
                auto it1 = reachability.find(from);
                if (it1 != reachability.end()) {
                    auto it2 = it1->second.find(to);
                    cout << " " << (it2 != it1->second.end() && it2->second ? "1" : "0") << " ";
                } else {
                    cout << " 0 ";
                }
            }
            cout << "\n";
        }
    }

    void findOptimalPath(const string& src, const string& dest) {
        cout << "\n===== SKYNET ROUTE SEARCH =====\n";
        cout << "Source     : " << src << "\n";
        cout << "Destination: " << dest << "\n";

        if (!reachability[src][dest]) {
            cout << "\n[RESULT] No path exists between " << src << " and " << dest << ".\n";
            return;
        }
        cout << "\n[OK] Path exists (verified via transitive closure)\n";

        map<string, bool> visited;
        FlightPath start;
        start.addStop(src);
        vector<FlightPath> all_paths;
        dfs(src, dest, visited, start, all_paths);

        if (all_paths.empty()) {
            cout << "[RESULT] No valid itinerary found.\n";
            return;
        }

        sort(all_paths.begin(), all_paths.end(),
             [](const FlightPath& a, const FlightPath& b) {
                 return a.getTotalDuration() < b.getTotalDuration();
             });

        cout << "\n----- ALL ITINERARIES (Ranked by Duration) -----\n";
        char label = 'A';
        for (auto& path : all_paths) {
            cout << "Path " << label++ << ": ";
            path.display();
            cout << "\n";
        }

        cout << "\n[OPTIMAL] Recommended path: ";
        all_paths[0].display();
        cout << "\n";
    }
};

// ============================================================
// MAIN
// ============================================================
int main() {
    cout << "===========================================\n";
    cout << "   SKYNET INTELLIGENT ROUTING SYSTEM\n";
    cout << "   Name: Ameena Batool | SP25-BSCS-0014\n";
    cout << "===========================================\n";

    SkyNet skynet;

    skynet.addAirport("KHI", "Jinnah Int'l Airport",   "Karachi",  "Pakistan");
    skynet.addAirport("DXB", "Dubai Int'l Airport",    "Dubai",    "UAE");
    skynet.addAirport("LHR", "Heathrow Airport",       "London",   "UK");
    skynet.addAirport("IST", "Istanbul Airport",       "Istanbul", "Turkey");
    skynet.addAirport("JFK", "John F Kennedy Airport", "New York", "USA");
    skynet.addAirport("DOH", "Hamad Int'l Airport",    "Doha",     "Qatar");

    skynet.addRoute("KHI", "DXB", 3,  "Emirates");
    skynet.addRoute("KHI", "LHR", 9,  "PIA");
    skynet.addRoute("KHI", "IST", 7,  "Turkish Airlines");
    skynet.addRoute("KHI", "DOH", 3,  "Qatar Airways");
    skynet.addRoute("DXB", "JFK", 14, "Emirates");
    skynet.addRoute("LHR", "JFK", 6,  "British Airways");
    skynet.addRoute("IST", "JFK", 10, "Turkish Airlines");
    skynet.addRoute("DOH", "LHR", 7,  "Qatar Airways");
    skynet.addRoute("DOH", "JFK", 13, "Qatar Airways");

    skynet.build();
    skynet.showAirports();
    skynet.showAdjacencyMatrix();
    skynet.showReachability();
    skynet.findOptimalPath("KHI", "JFK");

    return 0;
}